struct S {
    S() {}
};
