extern int foo();
