int foo();
